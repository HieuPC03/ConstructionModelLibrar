Dat file DWG vao thu muc nay.
FolderId: 01 — May moc thi cong phan tren / 上部工施工機械
Khai bao trong: Assets\Catalog\01.json
