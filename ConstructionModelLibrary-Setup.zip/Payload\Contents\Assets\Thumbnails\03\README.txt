PNG xem truoc cho thu muc 03.
