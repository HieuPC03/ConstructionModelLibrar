File catalog theo từng thư mục palette.

  01.json  →  Máy móc thi công phần trên / 上部工施工機械
  02.json  →  Phần dưới / 下部工施工機械
  03.json  →  Đường / 道路施工機械
  04.json  →  Chặn giao thông / 交通規制
  {custom-id}.json  →  Thư mục tự tạo trên palette

Mỗi file:
  { "Models": [ { "Id", "Name", "File", "BlockName", ... } ] }

File DWG đặt trong Assets/Models/{cùng-id}/
