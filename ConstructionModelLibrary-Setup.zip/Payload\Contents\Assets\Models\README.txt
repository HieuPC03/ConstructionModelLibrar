Đặt file DWG mô hình vào thư mục này.

Mỗi file DWG nên chứa 1 block (tên block khớp BlockName trong catalog.json).
Khuyến nghị: tạo block tại gốc (0,0,0), đơn vị mm hoặc m thống nhất với dự án.

Ví dụ:
  excavator-pc200.dwg  -> block "PC200"
  crane-tower-25t.dwg  -> block "TOWER_CRANE_25T"

Nguồn mô hình 3D:
  - Xuất từ Inventor / SolidWorks / Revit sang DWG
  - Tải thiết bị từ nhà cung cấp (định dạng DWG/DXF)
  - Tự mô hình 3D trong AutoCAD rồi BLOCK
