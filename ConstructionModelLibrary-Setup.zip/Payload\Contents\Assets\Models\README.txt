Mỗi thư mục con (01, 02, 03, 04, custom-...) tương ứng nhóm trên palette.

Cấu trúc:
  Assets/
    Catalog/01.json     ← danh sách mô hình thư mục 01
    Models/01/*.dwg     ← file DWG đặt tại đây
    Thumbnails/01/*.png ← ảnh xem trước

Thêm thư mục mới trên palette → tự tạo Models/{id}/, Catalog/{id}.json, Thumbnails/{id}/
