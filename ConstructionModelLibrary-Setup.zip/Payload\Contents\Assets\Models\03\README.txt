FolderId: 03 — May moc thi cong duong / 道路施工機械
Catalog: Assets\Catalog\03.json
