Đặt ảnh PNG thumbnail vào thư mục này.

Quy tắc tìm ảnh (theo thứ tự):
  1. Trường Thumbnail trong catalog.json (vd: excavator-pc200.png)
  2. {Id}.png (vd: excavator-pc200.png)
  3. {tên file DWG không đuôi}.png

Khuyến nghị: 256×256 px, nền trong hoặc xám nhạt.
Tạo ảnh: chụp màn hình VIEWSHOT trong AutoCAD, hoặc render từ mô hình gốc.
