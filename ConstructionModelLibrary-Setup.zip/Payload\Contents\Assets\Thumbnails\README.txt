Dat PNG cung ten file DWG (hoac truong Thumbnail trong catalog).
Vi du: Models/01/excavator.dwg → Thumbnails/01/excavator.png
