FolderId: 04 — Chan giao thong / 交通規制
Catalog: Assets\Catalog\04.json
