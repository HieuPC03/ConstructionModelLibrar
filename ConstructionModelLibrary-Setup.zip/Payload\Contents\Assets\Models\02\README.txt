FolderId: 02 — May moc thi cong phan duoi / 下部工施工機械
Catalog: Assets\Catalog\02.json
